package ro.ase.java;

public class Car extends Vehicle implements Transmission,Comparable<Car> {
	private int maximumSpeed;
	private String exComp;
	public Car() {
		super();
	}
	
	public Car(String exp, int maxSpeed) {
		this.exComp = exp;
		this.maximumSpeed = maxSpeed;
	}

	public String getExComp() {
		return exComp;
	}

	public void setExComp(String exComp) {
		this.exComp = exComp;
	}

	public int getMaximumSpeed() {
		return maximumSpeed;
	}

	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}

	@Override
	public boolean hasIntegralTransmission() {
		return true;
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((exComp == null)? 0: exComp.hashCode());
		return result;
	}
	
	public boolean equals(Car masina) {
		if(this.exComp.equals(masina.exComp))
			return true;
		else return false;
		
	}

	public void faraNume() {
		System.out.println("Salut");
	}
	@Override
	public int compareTo(Car masina) {
		return this.exComp.compareTo(masina.exComp);
	}
	
	

}
