﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SubiectContract
{
    public partial class Form1 : Form
    {
        public static Contract[] contracte = new Contract[50];
        public static int index = 0;
        public static readonly string filename="Contracte.dat";
        double valoareTotala = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(textBox1.Text);
            string denumire = textBox2.Text;
            double valoare = Double.Parse(textBox3.Text);
            Contract nou = new Contract(id, denumire, valoare);
            contracte[index] = nou;
            for(int i=0;i<= index;i++)
            {

                valoareTotala = valoareTotala + contracte[i];
            }
            textBox4.Clear();
            textBox4.Text = valoareTotala.ToString();
            index++;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            for(int i=0;i<numericUpDown1.Value;i++)
            {
                if (i < index)
                {
                    textBox1.Clear();
                    textBox1.Text = contracte[i].Cod.ToString();
                    textBox2.Clear();
                    textBox2.Text = contracte[i].Denumire;
                    textBox3.Clear();
                    textBox3.Text = contracte[i].Valoare.ToString();
                }
                else
                {
                    MessageBox.Show("valoare prea mare!");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            using (Stream stream = new FileStream(filename, FileMode.Create))
            {
                var formater = new BinaryFormatter();
                formater.Serialize(stream, contracte);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            using (StreamWriter writetext = new StreamWriter("write.txt"))
            {
                for (int i = 0; i < index; i++)
                {
                    writetext.WriteLine("ID:"+contracte[i].Cod.ToString());
                    writetext.WriteLine("Denumire:"+contracte[i].Denumire);
                    writetext.WriteLine("Valoare:"+contracte[i].Valoare.ToString());
                    writetext.WriteLine("\n");
                }
            }
        }

        private void optiuneGraficToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
