﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubiectConferita
{
    [Serializable]
    public class Sectiune
    {
        int codS;
        string denumS;

        public int CodS
        {
            get
            {
                return codS;
            }

            set
            {
                codS = value;
            }
        }

        public string DenumS
        {
            get
            {
                return denumS;
            }

            set
            {
                denumS = value;
            }
        }

        public Sectiune(int codS,string denumire)
        {
            this.CodS = codS;
            this.DenumS = denumire;
        }
        public Sectiune()
        {
            this.codS = 0;
            this.denumS = string.Empty;
        }
        public override string ToString()
        {
            return "Cod sectiune:" + codS + "denumire sectiune: " + denumS;
        }
    }
}
