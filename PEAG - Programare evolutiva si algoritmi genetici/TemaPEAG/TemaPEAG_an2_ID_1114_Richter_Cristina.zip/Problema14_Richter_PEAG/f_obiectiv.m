%creez functia fitness pentru f(x1,x2,x3 )=1+sin(2*x1-x3 )+x2

function [val] = f_obiectiv(x)
val=1+sin(2*(x(1))-x(3))+x(2);
end

