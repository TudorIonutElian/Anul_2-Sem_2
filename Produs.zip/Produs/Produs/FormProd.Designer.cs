﻿namespace Produs
{
    partial class FormProd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewProd = new System.Windows.Forms.ListView();
            this.Cod = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Denumire = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Pret = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonIncarca = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listViewProd
            // 
            this.listViewProd.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Cod,
            this.Denumire,
            this.Pret});
            this.listViewProd.GridLines = true;
            this.listViewProd.Location = new System.Drawing.Point(37, 33);
            this.listViewProd.Name = "listViewProd";
            this.listViewProd.Size = new System.Drawing.Size(227, 246);
            this.listViewProd.TabIndex = 0;
            this.listViewProd.UseCompatibleStateImageBehavior = false;
            this.listViewProd.View = System.Windows.Forms.View.Details;
            this.listViewProd.DoubleClick += new System.EventHandler(this.listViewProd_DoubleClick);
            // 
            // Cod
            // 
            this.Cod.Text = "Cod";
            this.Cod.Width = 35;
            // 
            // Denumire
            // 
            this.Denumire.Text = "Denumire";
            this.Denumire.Width = 132;
            // 
            // Pret
            // 
            this.Pret.Text = "Pret";
            this.Pret.Width = 56;
            // 
            // buttonIncarca
            // 
            this.buttonIncarca.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonIncarca.Location = new System.Drawing.Point(74, 310);
            this.buttonIncarca.Name = "buttonIncarca";
            this.buttonIncarca.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.buttonIncarca.Size = new System.Drawing.Size(154, 50);
            this.buttonIncarca.TabIndex = 1;
            this.buttonIncarca.Text = "Incarca date";
            this.buttonIncarca.UseVisualStyleBackColor = true;
            this.buttonIncarca.Click += new System.EventHandler(this.buttonIncarca_Click);
            // 
            // FormProd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 387);
            this.Controls.Add(this.buttonIncarca);
            this.Controls.Add(this.listViewProd);
            this.Name = "FormProd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormProd";
            this.Load += new System.EventHandler(this.FormProd_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listViewProd;
        private System.Windows.Forms.Button buttonIncarca;
        private System.Windows.Forms.ColumnHeader Cod;
        private System.Windows.Forms.ColumnHeader Denumire;
        private System.Windows.Forms.ColumnHeader Pret;
    }
}

