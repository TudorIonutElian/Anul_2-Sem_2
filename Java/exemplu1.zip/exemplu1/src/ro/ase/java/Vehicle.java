package ro.ase.java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.sun.javafx.collections.MappingChange.Map;

public abstract class  Vehicle {
	public final static double pi = 3.14;
	//private VehicleType type;
	private String marca;
	private int weight;
	
	static {
		System.out.println(pi);
	}
	
	public abstract void  faraNume();

	
	public String getMarca() {
		return this.marca;
	}

	public void setMarca(String m) {
		this.marca = m;
	}
	
	
	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
	

	@Override
	public String toString() {
		return new String(this.marca + " " + this.weight);
	}


	public static void main(String[] args) {
		List<Car> masini = new ArrayList<>();
		Car c1 = new Car("BMW",200);
		Car c2 = new Car("Audi",300);
		Car c3 = new Car("Ferrari",500);
		Car c4 = new Car("Trabant",50);
		masini.add(c1);
		masini.add(c2);
		if (c1 == c2) {
			System.out.println("Adevarat");
		}
		Collections.sort(masini);
		for(Car c:masini) {
			System.out.println(c.getExComp());
		}
		
		System.out.println("\nSet:");
		Set<Car> masiniSet = new HashSet();
		masiniSet.add(c1);
		masiniSet.add(c2);
		masiniSet.add(c3);
		masiniSet.add(c3);
		masiniSet.add(c4);
		
		for(Car c: masiniSet)
			System.out.println(c.getExComp());
		
		HashMap<String,Car> masiniMap = new HashMap<String,Car>();
		masiniMap.put("1",c1);
		masiniMap.put("2",c2);
		masiniMap.put("3",c3);
		System.out.println("Map: ");
		for(Entry<String,Car> entry:masiniMap.entrySet()) {
			System.out.println(entry.getValue().getExComp() + " " + entry.getKey());
			
		}
	}

	public boolean hasIntegralTransmission() {
		
		return false;
	}

}
