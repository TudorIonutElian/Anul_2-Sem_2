package ro.ase.java;

public interface Transmission {
	boolean hasIntegralTransmission();
}
