﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Produs
{
    [Serializable]
    class Prod
    {
        int cod;
        string denumire;        
        float pret;

        public int Cod
        {
            get { return cod; }
            set { cod = value; }
        }

        public string Denumire
        {
            get { return denumire; }
            set { denumire = value; }
        }
        
        public float Pret
        {
            get { return pret; }
            set { pret = value; }
        }

        public Prod()
        {
            cod = 0;
            denumire = string.Empty;
            pret = 0;
        }

        public Prod(int c, string d, float p)
        {
            this.cod = c;
            this.denumire = d;
            this.pret = p;
        }

        public string toString()
        {
            return "Cod produs: " + this.cod + ", denumire produs: " + this.denumire + ", pret: " + this.pret + ".";
        }
    }
}
