﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubiectContract
{
    [Serializable]
    public class Contract
    {
       private int cod;
       private string denumire;
       private double valoare;

        public Contract()
        {

        }
        public int Cod
        {
            get
            {
                return cod;
            }

            set
            {
                cod = value;
            }
        }

        public string Denumire
        {
            get
            {
                return denumire;
            }

            set
            {
                denumire = value;
            }
        }

        public double Valoare
        {
            get
            {
                return valoare;
            }

            set
            {
                valoare = value;
            }
        }

        public Contract(int cod,string denumire,double valoare)
        {
            this.cod = cod;
            this.Denumire = denumire;
            this.valoare = valoare;
        }
        public static double operator +(double valoare,Contract c)
        {
            return c.valoare + valoare;
        }

    }
}
