﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SubiectApartament
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 

        }
        OleDbDataAdapter da;
        OleDbConnection conn;
        DataSet ds;
        private void button1_Click(object sender, EventArgs e)
        {
            
            ds = new DataSet();           
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Gabi\Desktop\SubiectApartament\SubiectApartament\Apartament1.accdb");
            conn.Open();
            da = new OleDbDataAdapter("Select * from apartamente", conn);
            da.Fill(ds, "apartamente");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "apartamente";
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
        
            
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;

            OleDbCommand oc =conn.CreateCommand();
            oc.CommandType = CommandType.Text;
            if (dataGridView1.Rows[i].Cells["cod"].Value.ToString()!= "")
            { oc.CommandText = "update apartamente set latime='" +
                             dataGridView1.Rows[i].Cells["latime"].Value.ToString() + "',lungime='" +
                             dataGridView1.Rows[i].Cells["lungime"].Value.ToString() + "',orientare='" +
                             dataGridView1.Rows[i].Cells["orientare"].Value.ToString() + "' where cod=" +
                             i + "";}
            else
            {
                int k= Convert.ToInt32(dataGridView1.Rows[e.RowIndex - 1].Cells["cod"].Value);
                k++;
                if (dataGridView1.Rows[i].Cells["latime"].Value.ToString() != "" &&
                    dataGridView1.Rows[i].Cells["lungime"].Value.ToString() != "" &&
                    dataGridView1.Rows[i].Cells["orientare"].Value.ToString() != "")
                { oc.CommandText = "insert into apartamente values('"+ k.ToString()+"','" +
                             dataGridView1.Rows[e.RowIndex].Cells["latime"].Value.ToString()  +"','"+
                             dataGridView1.Rows[e.RowIndex].Cells["lungime"].Value.ToString() +"','"+
                             dataGridView1.Rows[e.RowIndex].Cells["orientare"].Value.ToString() +
                               "')";}
            }
            oc.Connection = conn;
            if(oc.CommandText!="")
            {  oc.ExecuteNonQuery();}
        }
        List<Camera> l=new List<Camera>();
        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount-1; i++)
            {
               
                    int cod = (int)dataGridView1.Rows[i].Cells["cod"].Value;
                    int latime= Convert.ToInt32(dataGridView1.Rows[i].Cells["latime"].Value.ToString());
                int lungime = Convert.ToInt32(dataGridView1.Rows[i].Cells["lungime"].Value.ToString());
                Orinetare o;
                String s = dataGridView1.Rows[i].Cells["orientare"].Value.ToString();
                if (s.CompareTo("S") == 0)
                {
                    o = Orinetare.S;
                }
            else    if (s.CompareTo("V") == 0)
                {
                    o = Orinetare.V;
                }
             else   if (s.CompareTo("N") == 0)
                {
                    o = Orinetare.N;
                }
   else if (s.CompareTo("E") == 0)
   {
       o = Orinetare.E;
   }
   else
   {
       o=Orinetare.NEDENIFIT;
   }
                l.Add(new Camera(cod,latime,lungime,o));
            }
            ListViewItem itm;
            foreach (Camera c in l)
            {
                itm=new ListViewItem(c.Cod.ToString());
                itm.SubItems.Add(c.Latime.ToString());
                itm.SubItems.Add(c.Lungime.ToString());
                itm.SubItems.Add(c.Orientare.ToString());
                listView1.Items.Add(itm);
            }
        }
    }
}
