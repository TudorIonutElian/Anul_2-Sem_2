﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SubiectConferita
{
    public partial class Form3 : Form
    {
        LinkedList<Lucrari> lucrari = new LinkedList<Lucrari>();
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (Stream stream = new FileStream("DateNoiLucrari.dat", FileMode.Open))
            {
                BinaryFormatter br = new BinaryFormatter();
                lucrari = (LinkedList<Lucrari>)br.Deserialize(stream);
                //lucrari = br.Read();

                foreach (Lucrari l in lucrari)
                {
                    ListViewItem itm = new ListViewItem(l.CodL.ToString());
                    itm.SubItems.Add(l.DenumL);
                    itm.SubItems.Add(l.Sectiune.ToString());
                    listView1.Items.Add(itm);

                }

            }
        }
    }
}
