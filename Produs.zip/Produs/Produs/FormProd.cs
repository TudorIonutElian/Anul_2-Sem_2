﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Produs
{
    public partial class FormProd : Form
    {
        public static ArrayList lstProd = new ArrayList();

        public void salveazaProd()
        {
            Prod[] vect = new Prod[4];
            vect[0] = new Prod(1, "Mango", 10);
            vect[1] = new Prod(2, "Kiwi", 15);
            vect[2] = new Prod(3, "Avocado", 20);
            vect[3] = new Prod(4, "Ananas", 25);
            lstProd.AddRange(vect);
        }

        public FormProd()
        {
            InitializeComponent();
        }

        private void FormProd_Load(object sender, EventArgs e)
        {
            salveazaProd();
        }

        private void buttonIncarca_Click(object sender, EventArgs e)
        {
            foreach (Prod pr in lstProd)
            {
                ListViewItem lvi = new ListViewItem(pr.Cod.ToString());
                lvi.SubItems.Add(pr.Denumire);
                lvi.SubItems.Add(pr.Pret.ToString());
                listViewProd.Items.Add(lvi);
            }
            MessageBox.Show("Datele au fost adaugate!");
        }

        private void listViewProd_DoubleClick(object sender, EventArgs e)
        {
            ListViewItem lvi = listViewProd.SelectedItems[0];
            int index = listViewProd.SelectedItems[0].Index;
            DetaliiProdus dp = new DetaliiProdus();
            Prod p = new Prod();
            dp.textBoxCod.Text = lvi.SubItems[0].Text;
            dp.textBoxDenumire.Text = lvi.SubItems[1].Text;
            dp.textBoxPret.Text = lvi.SubItems[2].Text;
            dp.ShowDialog();

            if (dp.DialogResult == DialogResult.OK)
            {
                lvi.SubItems[0].Text = dp.textBoxCod.Text;
                lvi.SubItems[1].Text = dp.textBoxDenumire.Text;
                lvi.SubItems[2].Text = dp.textBoxPret.Text;
                p = (Prod)lstProd[index];
                p.Cod = int.Parse(dp.textBoxCod.Text);
                p.Denumire = dp.textBoxDenumire.Text;
                p.Pret = float.Parse(dp.textBoxPret.Text);
            }
            else
            {
                MessageBox.Show("Nu s-au facut modificari!");
            }
        }
    }
}
