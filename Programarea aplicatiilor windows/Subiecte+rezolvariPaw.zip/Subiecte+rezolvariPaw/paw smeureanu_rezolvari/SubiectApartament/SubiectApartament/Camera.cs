﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubiectApartament
{
    public enum Orinetare {NEDENIFIT=0,E=1,V=2,N=3,S=4};
    class Camera
    {
        private int cod;
        private int latime;
        private int lungime;
        Orinetare orientare;

        public int Cod
        {
            get
            {
                return cod;
            }

            set
            {
                cod = value;
            }
        }

        public int Latime
        {
            get
            {
                return latime;
            }

            set
            {if(latime>0)
                latime = value;
                else
                {
                    throw new Exception("Valoare invalida!");
                }
            }
        }

        public int Lungime
        {
            get
            {
                return lungime;
            }

            set
            {
                if (lungime > 0)
                    lungime = value;
                else
                {
                    throw new Exception("Valoare invalida!");
                }
            }
        }

        public Orinetare Orientare
        {
            get { return orientare; }
            set { orientare = value; }
        }

        public Camera(int cod,int latime,int lungime,Orinetare orientare)
        {
            this.cod = cod;
            this.latime = latime;
            this.orientare = orientare;
            this.lungime = lungime;
        }
        public Camera()
        {
            this.cod = 0;
            this.latime = 0;
            this.lungime = 0;
            this.orientare = Orinetare.NEDENIFIT;
        }
    }
}
