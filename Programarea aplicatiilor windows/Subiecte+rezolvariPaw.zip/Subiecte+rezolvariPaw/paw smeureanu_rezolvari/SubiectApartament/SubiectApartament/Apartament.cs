﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubiectApartament
{
    class Apartament
    {
        private int codA;
        private int nrCamere;
        private Camera[] camere = new Camera[5];

        public int CodA
        {
            get
            {
                return codA;
            }

            set
            {
                codA = value;
            }
        }

        public int NrCamere
        {
            get
            {
                return nrCamere;
            }

            set
            {
                nrCamere = value;
            }
        }

        internal Camera[] Camere
        {
            get
            {
                return camere;
            }

            set
            {
                camere = value;
            }
        }
        public Apartament()
        {
            this.codA = 0;
            this.nrCamere = 0;
            this.camere = null;
        }
        public Apartament(int codA,int nrCamere,Camera[] camere)
        {
            this.codA = codA;
            this.nrCamere = nrCamere;
            this.camere = camere;
        }
        public int calculSuprafata()
        {
            int suprafataTotala = 0;
            for(int i=0;i<nrCamere;i++)
            {
                if(camere[i]!=null)
                suprafataTotala += (camere[i].Latime * camere[i].Lungime);
            }
            return suprafataTotala;
        }


    }
}
