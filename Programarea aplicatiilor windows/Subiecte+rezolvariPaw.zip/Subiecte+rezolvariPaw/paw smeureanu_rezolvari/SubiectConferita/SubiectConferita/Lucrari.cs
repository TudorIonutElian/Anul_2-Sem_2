﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubiectConferita
{
    [Serializable]
    public class Lucrari
    {
        int codL;
        string denumL;
        int sectiune;

        public Lucrari(int cod,string nume,int sectiune)
        {
            this.CodL = cod;
            this.DenumL = nume;
            this.Sectiune = sectiune;
        }

        public int CodL
        {
            get
            {
                return codL;
            }

            set
            {
                codL = value;
            }
        }

        public string DenumL
        {
            get
            {
                return denumL;
            }

            set
            {
                denumL = value;
            }
        }

        public int Sectiune
        {
            get
            {
                return sectiune;
            }

            set
            {
                sectiune = value;
            }
        }
        public override string ToString()
        {
            return "Cod " + this.codL + " denumire lucrare " + this.denumL + " sectiune:" + this.sectiune;
        }
    }
}
