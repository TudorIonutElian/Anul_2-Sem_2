﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SubiectConferita
{
    public partial class Form1 : Form
    {
        public static LinkedList<Sectiune> lstSectiuni = new LinkedList<Sectiune>();
        public static LinkedList<Lucrari> lstLucrari = new LinkedList<Lucrari>();
        public static int index;
        public Form1()
        {
            InitializeComponent();
            salvareDate();
            
        }
 
        public void salvareDate()
        {
            StreamReader sr = new StreamReader("Lucrari.dat");
            string line = sr.ReadLine();
            while(line !=null)
            {
                int codL = Int32.Parse(line);
                line = sr.ReadLine();
                string denumL=line;
                line = sr.ReadLine();
                int sectiune=Int32.Parse(line);
                line = sr.ReadLine();
                Lucrari nou = new Lucrari(codL,denumL,sectiune);
                lstLucrari.AddLast(nou);
            }
            sr = new StreamReader("Sectiune.dat");
            line = sr.ReadLine();
            while (line != null)
            {
                int codS=Int32.Parse(line);
                line = sr.ReadLine();
                string denumS =line;
                line = sr.ReadLine();
                Sectiune nou = new Sectiune(codS, denumS);
                lstSectiuni.AddLast(nou);
                
            }
            
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int codSectiune=0;
            foreach (Sectiune s in lstSectiuni)
            {
                if(s.DenumS==comboBox1.SelectedText)
                {
                    codSectiune = s.CodS;
                }
            }
            int durata=0;
            foreach (Lucrari l in lstLucrari)
            {
                durata = durata + 15;
                if(l.Sectiune==codSectiune)
                {
                    ListViewItem itm = new ListViewItem(l.CodL.ToString());
                    itm.SubItems.Add(l.DenumL);
                    itm.SubItems.Add(l.Sectiune.ToString());
                    itm.SubItems.Add(durata.ToString());
                    listView2.Items.Add(itm);

                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Lucrari l in lstLucrari)
            {
                ListViewItem itm = new ListViewItem(l.CodL.ToString());
                itm.SubItems.Add(l.DenumL);
                itm.SubItems.Add(l.Sectiune.ToString());
                listView1.Items.Add(itm);
            }
            foreach (Sectiune s in lstSectiuni)
            {
                comboBox1.Items.Add(s.DenumS);
            }
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {

            Form2 frm = new Form2(this);
            frm.ShowDialog();
           
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            int codSectiune = 0;
            foreach (Sectiune s in lstSectiuni)
            {
                if (s.DenumS == comboBox1.Text)
                {
                    codSectiune = s.CodS;
                }
            }
            int durata = 0;
            foreach (Lucrari l in lstLucrari)
            {
                durata = durata + 15;
                if (l.Sectiune == codSectiune)
                {
                    ListViewItem itm = new ListViewItem(l.CodL.ToString());
                    itm.SubItems.Add(l.DenumL);
                    itm.SubItems.Add(l.Sectiune.ToString());
                    itm.SubItems.Add(durata.ToString());
                    listView2.Items.Add(itm);

                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            using (Stream stream = new FileStream("DateNoiLucrari.dat", FileMode.Create))
            {
                BinaryFormatter bw = new BinaryFormatter();
                bw.Serialize(stream, lstLucrari);
            }
            using (Stream stream = new FileStream("DateNoiSectiuni.dat", FileMode.Create))
            {
                BinaryFormatter bw = new BinaryFormatter();
                bw.Serialize(stream, lstSectiuni);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
        }
    }
}
