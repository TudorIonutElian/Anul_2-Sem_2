﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SubiectContract
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            for(int i=0;i<Form1.index;i++)
            {
                chart1.Series["Valoare"].Points.AddXY( i, Form1.contracte[i].Valoare);
            }
            for(int i=0;i<Form1.index;i++)
            {
                chart1.Series["Cod"].Points.AddXY(i, Form1.contracte[i].Cod);
            }
        }
    }
}
