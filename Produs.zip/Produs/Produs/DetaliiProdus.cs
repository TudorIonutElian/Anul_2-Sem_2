﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Produs
{
    public partial class DetaliiProdus : Form
    {
        public DetaliiProdus()
        {
            InitializeComponent();
        }

        private void labelCod_Click(object sender, EventArgs e)
        {

        }
    }
}
