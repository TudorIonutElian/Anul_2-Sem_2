﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SubiectConferita
{
    public partial class Form2 : Form
    {
        public Form1 ths;
        public Form2(Form1 form)
        {
            InitializeComponent();
            ths = form;
            ListViewItem itm = ths.listView1.FocusedItem;
            textBox1.Text = itm.Text;
            textBox2.Text = itm.SubItems[1].Text;
            textBox3.Text = itm.SubItems[2].Text;
         
            
               
        } 
  
      
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1.lstLucrari.ElementAt(ths.listView1.FocusedItem.Index).CodL = Int32.Parse(textBox1.Text);
            Form1.lstLucrari.ElementAt(ths.listView1.FocusedItem.Index).DenumL = textBox2.Text;
            Form1.lstLucrari.ElementAt(ths.listView1.FocusedItem.Index).Sectiune = Int32.Parse(textBox3.Text);

            ListViewItem itm = new ListViewItem(textBox1.Text);
            itm.SubItems.Add(textBox2.Text);
            itm.SubItems.Add(textBox3.Text);
            ths.listView1.Items.RemoveAt(ths.listView1.FocusedItem.Index);
            ths.listView1.Items.Add(itm);

            this.Close();
        
        }
    }
}
